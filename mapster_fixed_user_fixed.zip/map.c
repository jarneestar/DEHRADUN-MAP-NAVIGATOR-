#include <math.h>
#include <stdlib.h>
#include <float.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

double distance(double lat1, double lon1, double lat2, double lon2) {
    double R = 6371.0;
    double dLat = (lat2 - lat1) * M_PI / 180.0;
    double dLon = (lon2 - lon1) * M_PI / 180.0;
    double la1 = lat1 * M_PI / 180.0;
    double la2 = lat2 * M_PI / 180.0;

    double a = sin(dLat/2.0)*sin(dLat/2.0) +
               cos(la1)*cos(la2)*sin(dLon/2.0)*sin(dLon/2.0);

    double c = 2.0 * atan2(sqrt(a), sqrt(1.0-a));
    return R * c;
}

double route_distance(double *lats, double *lngs, int n) {
    if (n < 2) return 0.0;
    double total = 0.0;
    for (int i = 0; i < n-1; ++i) {
        total += distance(lats[i], lngs[i], lats[i+1], lngs[i+1]);
    }
    return total;
}

int dijkstra(int n, double **distMatrix, int start, int end, int *outPath) {
    double *dist = (double*)malloc(n * sizeof(double));
    int *prev = (int*)malloc(n * sizeof(int));
    int *visited = (int*)calloc(n, sizeof(int));

    for (int i = 0; i < n; ++i) {
        dist[i] = DBL_MAX;
        prev[i] = -1;
    }
    dist[start] = 0.0;

    for (int iter = 0; iter < n; ++iter) {
        double minD = DBL_MAX;
        int u = -1;
        for (int v = 0; v < n; ++v) {
            if (!visited[v] && dist[v] < minD) {
                minD = dist[v];
                u = v;
            }
        }
        if (u == -1) break;
        visited[u] = 1;
        if (u == end) break;

        for (int v = 0; v < n; ++v) {
            double w = distMatrix[u][v];
            if (w > 0.0) {
                double alt = dist[u] + w;
                if (alt < dist[v]) {
                    dist[v] = alt;
                    prev[v] = u;
                }
            }
        }
    }

    int count = 0;
    for (int at = end; at != -1 && count < n; at = prev[at]) {
        outPath[count++] = at;
    }

    for (int i = 0; i < count/2; ++i) {
        int tmp = outPath[i];
        outPath[i] = outPath[count - i - 1];
        outPath[count - i - 1] = tmp;
    }

    free(dist);
    free(prev);
    free(visited);
    return count;
}
