#!/usr/bin/env bash
set -e

gcc -shared -fPIC -o map.so map.c -lm

echo "Built map.so"
