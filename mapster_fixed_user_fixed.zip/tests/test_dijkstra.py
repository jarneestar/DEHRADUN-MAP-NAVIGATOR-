import requests
print('Posting sample dijkstra request...')
url='http://localhost:5000/dijkstra'
payload={"points":[[30.3185,78.0290],[30.3655,78.0421]]}
r=requests.post(url,json=payload)
print(r.status_code, r.text)
