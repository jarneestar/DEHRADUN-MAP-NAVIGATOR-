from flask import Flask, request, jsonify, render_template, send_from_directory
from flask_cors import CORS
import ctypes, os, math, platform

app = Flask(__name__, static_folder='../static', template_folder='../templates')
CORS(app)

# DLL path (place map.dll at project root next to folders)
DLL_PATH = os.path.join(os.path.dirname(__file__), '..', 'map.dll')
clib = None
dll_loaded = False

if os.path.exists(DLL_PATH):
    try:
        clib = ctypes.CDLL(DLL_PATH)
        clib.distance.argtypes = (ctypes.c_double, ctypes.c_double, ctypes.c_double, ctypes.c_double)
        clib.distance.restype = ctypes.c_double
        clib.dijkstra.argtypes = (
            ctypes.c_int,
            ctypes.POINTER(ctypes.POINTER(ctypes.c_double)),
            ctypes.c_int,
            ctypes.c_int,
            ctypes.POINTER(ctypes.c_int)
        )
        clib.dijkstra.restype = ctypes.c_int
        dll_loaded = True
        print("Loaded DLL:", DLL_PATH)
    except Exception as e:
        print("Warning: failed to load DLL:", e)
        clib = None

# Points
points = [
    {"id": 0, "name": "Clock Tower", "lat": 30.3185, "lng": 78.0290},
    {"id": 1, "name": "Robber's Cave", "lat": 30.3655, "lng": 78.0421},
    {"id": 2, "name": "Forest Research Institute", "lat": 30.3401, "lng": 77.9960},
    {"id": 3, "name": "Sahasradhara", "lat": 30.3874, "lng": 78.1318},
    {"id": 4, "name": "Tapkeshwar Temple", "lat": 30.3440, "lng": 78.0066},
    {"id": 5, "name": "Pacific Mall", "lat": 30.3446, "lng": 78.0531},
    {"id": 6, "name": "ISBT Dehradun", "lat": 30.2857, "lng": 78.0081},
    {"id": 7, "name": "Mussoorie Road", "lat": 30.3794, "lng": 78.0859},
    {"id": 8, "name": "Rajpur Road", "lat": 30.3707, "lng": 78.0758},
    {"id": 9, "name": "Dehradun Zoo", "lat": 30.3600, "lng": 78.0450},
]

graph_edges = [
    (0,5),(0,8),(5,8),(8,7),(7,1),(1,9),(9,5),(2,4),(2,0),(6,4)
]

def haversine(lat1, lon1, lat2, lon2):
    R = 6371.0
    phi1 = math.radians(lat1); phi2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1); dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi/2)**2 + math.cos(phi1)*math.cos(phi2)*math.sin(dlambda/2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    return R * c

def distance_using_lib(lat1, lon1, lat2, lon2):
    if dll_loaded:
        try:
            return float(clib.distance(lat1, lon1, lat2, lon2))
        except Exception:
            return haversine(lat1, lon1, lat2, lon2)
    return haversine(lat1, lon1, lat2, lon2)

def build_landmark_matrix():
    n = len(points)
    MatrixType = ctypes.POINTER(ctypes.c_double) * n
    row_type = ctypes.c_double * n
    matrix = MatrixType()
    for i in range(n):
        row = row_type()
        for j in range(n):
            row[j] = 0.0
        matrix[i] = row
    for (a,b) in graph_edges:
        p1 = points[a]; p2 = points[b]
        d = distance_using_lib(p1['lat'], p1['lng'], p2['lat'], p2['lng'])
        matrix[a][b] = d; matrix[b][a] = d
    return matrix

def nearest_landmark(lat, lng):
    best = None; bestd = float('inf')
    for p in points:
        d = distance_using_lib(lat, lng, p['lat'], p['lng'])
        if d < bestd:
            bestd = d; best = p['id']
    return best, bestd

@app.get('/')
def home():
    return render_template('index_nojs.html', points=points)

@app.post('/search_location')
def search_location():
    query = request.form.get("query", "").strip().lower()
    for p in points:
        if query in p["name"].lower():
            return jsonify({"status":"ok","lat":p["lat"],"lng":p["lng"],"name":p["name"]})
    return jsonify({"status":"not_found"})

@app.post('/straight_distance')
def straight_distance_api():
    data = request.get_json() or {}
    lat1 = float(data.get('lat1')); lng1 = float(data.get('lng1'))
    lat2 = float(data.get('lat2')); lng2 = float(data.get('lng2'))
    d = distance_using_lib(lat1,lng1,lat2,lng2)
    return jsonify({"distance": round(d, 3)})

@app.post('/dijkstra')
def dijkstra_api():
    data = request.get_json() or {}
    coords = data.get('points')
    if not coords or len(coords) < 2:
        return jsonify({'error':'Need at least 2 points'}), 400
    n_land = len(points)
    matrix = build_landmark_matrix()
    full_path = []
    for idx in range(len(coords)-1):
        start = coords[idx]; end = coords[idx+1]
        s_lat, s_lng = float(start[0]), float(start[1])
        e_lat, e_lng = float(end[0]), float(end[1])
        s_idx, _ = nearest_landmark(s_lat, s_lng)
        e_idx, _ = nearest_landmark(e_lat, e_lng)
        outBuf = (ctypes.c_int * n_land)()
        path_len = 0
        if dll_loaded:
            try:
                path_len = clib.dijkstra(ctypes.c_int(n_land), matrix, ctypes.c_int(s_idx), ctypes.c_int(e_idx), outBuf)
            except Exception:
                path_len = 0
        if path_len == 0:
            outBuf[0] = s_idx; outBuf[1] = e_idx; path_len = 2
        segment = []
        if idx == 0:
            segment.append([s_lat, s_lng])
        if not (abs(s_lat - points[s_idx]['lat'])<1e-9 and abs(s_lng - points[s_idx]['lng'])<1e-9):
            segment.append([points[s_idx]['lat'], points[s_idx]['lng']])
        for i in range(path_len):
            node = int(outBuf[i])
            if not segment or segment[-1] != [points[node]['lat'], points[node]['lng']]:
                segment.append([points[node]['lat'], points[node]['lng']])
        if not (segment and segment[-1] == [e_lat, e_lng]):
            segment.append([e_lat, e_lng])
        if full_path and full_path[-1] == segment[0]:
            full_path.extend(segment[1:])
        else:
            full_path.extend(segment)
    total = 0.0
    for i in range(len(full_path)-1):
        a = full_path[i]; b = full_path[i+1]
        total += distance_using_lib(a[0], a[1], b[0], b[1])
    return jsonify({'path': full_path, 'total_km': round(total,3)})

@app.get('/leaflet.html')
def map_view():
    return send_from_directory('../static','leaflet.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
