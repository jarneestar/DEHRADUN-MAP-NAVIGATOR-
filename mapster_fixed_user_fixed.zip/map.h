#ifndef MAP_H
#define MAP_H

double distance(double lat1, double lon1, double lat2, double lon2);
double route_distance(double *lats, double *lngs, int n);
int dijkstra(int n, double **distMatrix, int start, int end, int *outPath);

#endif // MAP_H
